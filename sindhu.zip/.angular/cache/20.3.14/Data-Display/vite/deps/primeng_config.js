import {
  PRIME_NG_CONFIG,
  PrimeNG,
  ThemeProvider,
  providePrimeNG
} from "./chunk-JWZI37AH.js";
import "./chunk-T5PHZI4G.js";
import "./chunk-K2WABBE6.js";
import "./chunk-J726HDAC.js";
import "./chunk-R6U7IGMG.js";
import "./chunk-PELCLBLS.js";
import "./chunk-RSS3ODKE.js";
import "./chunk-XWLXMCJQ.js";
export {
  PRIME_NG_CONFIG,
  PrimeNG,
  ThemeProvider,
  providePrimeNG
};
